<?php

namespace app\index\model;

use think\Model;

class User extends Model
{
    /**
     * 初始化模型类
     */
    protected function initialize(){
        parent::initialize();
    }
}
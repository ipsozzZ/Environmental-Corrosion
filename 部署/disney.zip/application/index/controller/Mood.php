<?php
namespace app\index\controller;

use think\Controller;

class Mood extends Common
{
    public function index(){
        return view();
    }
}
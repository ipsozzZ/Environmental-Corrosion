<?php
//配置文件
return [
  'view_replace_str' => [
    '__IMG__' => '/static/mobile/image',
    '__ICON__' => '/static/mobile/image/icon',
    '__CSS__' => '/static/mobile/custom/css',
    '__JS__' => '/static/mobile/custom/js',
  ],
];
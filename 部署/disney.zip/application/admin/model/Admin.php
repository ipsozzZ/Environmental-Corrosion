<?php

namespace app\admin\model;

use think\Model;

class Admin extends Common
{
    protected function initialize(){
        parent::initialize();
    }
}

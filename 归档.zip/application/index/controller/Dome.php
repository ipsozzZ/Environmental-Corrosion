<?php
namespace app\index\controller;

use think\Controller;

class Dome extends Common
{
    public function index(){
        return view();
    }
    
    public function detail(){
        return view();
    }
}
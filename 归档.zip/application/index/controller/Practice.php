<?php
/**
 * Created by PhpStorm.
 * User: 19753
 * Date: 2018/10/23
 * Time: 18:39
 */

namespace app\index\controller;


use think\Controller;

class Practice extends Common
{
    public function index(){
        return view();
    }

    public function info(){
        return view();
    }
}